from ekyc import process_id_verification
import json

result = process_id_verification('/Users/prabhjeevan/Documents/Data_Science/juara_ekyc/UserFaces/prabh1.jpg')
print(result)