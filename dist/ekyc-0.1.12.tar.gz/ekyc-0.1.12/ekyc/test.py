from ekyc import process_id_verification
import json

result = process_id_verification('/Users/prabhjeevan/Documents/Data_Science/Facial_Matching/UserFaces/prabh1.jpg')
print(result)